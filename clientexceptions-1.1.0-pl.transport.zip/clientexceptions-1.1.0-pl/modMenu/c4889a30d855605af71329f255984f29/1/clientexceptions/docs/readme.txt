----------------------
Client Exceptions
----------------------
Version: 1.1.0
Author: Oene Tjeerd de Bruin
Contact: modx@oetzie.nl
----------------------

This use this component the user needs to have the "clientexceptions" permissions.